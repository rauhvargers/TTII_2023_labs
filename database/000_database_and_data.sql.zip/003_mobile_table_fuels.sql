SET FOREIGN_KEY_CHECKS=0;

INSERT INTO fuels (id, title) VALUES
(1, 'Benzīns'),
(2, 'Benzīns un gāze'),
(3, 'Benzīns un naftas gāze'),
(4, 'Dīzeļdegviela'),
(5, 'Gāze'),
(6, 'Naftas gāze'),
(7, 'Benzīns un dabas gāze'),
(8, 'Elektrība'),
(9, 'Dabas gāze'),
(10, 'Dīzeļdegviela un gāze'),
(11, 'Dīzeļdegviela un naftas gāze'),
(12, 'Dabas gāze un naftas gāze'),
(13, 'Elektrība un benzīns'),
(14, 'Dīzeļdegviela un dabas gāze'),
(15, 'Elektrība un dīzeļdegviela');
